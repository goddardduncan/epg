var supportedVersions = ["1.1.5","1.0.12","0.14.16"]
var currentVersion = supportedVersions[0]