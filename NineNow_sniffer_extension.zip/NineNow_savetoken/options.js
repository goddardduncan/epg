document.addEventListener('DOMContentLoaded', function () {
    const saveButton = document.getElementById('save-button');
    const tokenInput = document.getElementById('github-token');
    const pathInput = document.getElementById('github-path');

    // Load the saved token and path from storage
    chrome.storage.local.get(['githubToken', 'githubPath'], function (result) {
        if (result.githubToken) {
            tokenInput.value = result.githubToken;
        }
        if (result.githubPath) {
            pathInput.value = result.githubPath;
        }
    });

    // Save the token and path to storage when the save button is clicked
    saveButton.addEventListener('click', function () {
        const githubToken = tokenInput.value;
        const githubPath = pathInput.value;
        if (githubToken && githubPath) {
            chrome.storage.local.set({ githubToken: githubToken, githubPath: githubPath }, function () {
                alert('GitHub token and path saved!');
            });
        } else {
            alert('Please fill in both the token and path fields.');
        }
    });
});
