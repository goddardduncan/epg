(function() {
    'use strict';

    const TOGGLE_KEY = 'sniffAwayToggle';
    let isSniffing = JSON.parse(localStorage.getItem(TOGGLE_KEY)) || false;

    const urlsToVisit = [
        'https://www.9now.com.au/live/channel-9',
        'https://www.9now.com.au/live/gem',
        'https://www.9now.com.au/live/go',
        'https://www.9now.com.au/live/life',
        'https://www.9now.com.au/live/rush'
    ];

    const channelIds = {
        'https://www.9now.com.au/live/channel-9': 'mjh-channel-9-vic',
        'https://www.9now.com.au/live/gem': 'mjh-gem-vic',
        'https://www.9now.com.au/live/go': 'mjh-go-vic',
        'https://www.9now.com.au/live/life': 'mjh-life-vic',
        'https://www.9now.com.au/live/rush': 'mjh-rush-vic'
    };

    let clipboardContents = sessionStorage.getItem('clipboardContents') ? JSON.parse(sessionStorage.getItem('clipboardContents')) : {};

    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            console.log('Stream URL copied to clipboard:', text);
        }).catch(err => {
            console.error('Failed to copy to clipboard:', err);
        });
    }

    function clearClipboard() {
        sessionStorage.removeItem('clipboardContents');
        clipboardContents = {};
        console.log('Clipboard cleared');
    }

    function handleStreamUrl() {
        if (!isSniffing) return;

        const element = document.querySelector('[data-param-live-stream-url]');
        if (element && element.getAttribute('data-param-live-stream-url')) {
            const currentUrl = window.location.href;
            const channelId = channelIds[currentUrl];
            clipboardContents[channelId] = element.getAttribute('data-param-live-stream-url');
            sessionStorage.setItem('clipboardContents', JSON.stringify(clipboardContents));
            navigateToNextUrl();
        }
    }

    function navigateToNextUrl() {
        const currentUrl = window.location.href;
        const currentIndex = urlsToVisit.indexOf(currentUrl);

        if (currentIndex > -1 && currentIndex < urlsToVisit.length - 1) {
            const nextUrl = urlsToVisit[currentIndex + 1];
            window.location.href = nextUrl;
        } else {
            console.log('All URLs visited, preparing clipboard.');
            prepareClipboardText();
        }
    }

    function prepareClipboardText() {
        const updatedChannelLinkMap = {
            "mjh-channel-9-vic": clipboardContents['mjh-channel-9-vic'] || "",
            "mjh-gem-vic": clipboardContents['mjh-gem-vic'] || "",
            "mjh-go-vic": clipboardContents['mjh-go-vic'] || "",
            "mjh-life-vic": clipboardContents['mjh-life-vic'] || "",
            "mjh-rush-vic": clipboardContents['mjh-rush-vic'] || ""
        };

        const timestamp = new Date().toISOString();
        
        const formattedText = `{
    "timestamp": "${timestamp}",
    "mjh-channel-9-vic": "${updatedChannelLinkMap['mjh-channel-9-vic']}",
    "mjh-gem-vic": "${updatedChannelLinkMap['mjh-gem-vic']}",
    "mjh-go-vic": "${updatedChannelLinkMap['mjh-go-vic']}",
    "mjh-life-vic": "${updatedChannelLinkMap['mjh-life-vic']}",
    "mjh-rush-vic": "${updatedChannelLinkMap['mjh-rush-vic']}"
}`;

        copyToClipboard(formattedText);
        getGithubTokenAndUpdateFile(formattedText); // Update the text on GitHub after preparation
        turnOffSniffing(); // Turn off sniffing
    }

    function turnOffSniffing() {
        isSniffing = false;
        localStorage.setItem(TOGGLE_KEY, JSON.stringify(isSniffing));
        updateToggleHTML();
    }

    function checkIfUpdateNeeded() {
        chrome.runtime.sendMessage({ action: "getGithubToken" }, function(response) {
            const token = response.token;
            if (!token) {
                console.error("GitHub token not found!");
                return;
            }

            fetch(`https://api.github.com/repos/goddardduncan/epg/contents/9now.json`, {
                method: "GET",
                headers: {
                    "Authorization": `token ${token}`,
                    "Content-Type": "application/json"
                }
            })
            .then(response => response.json())
            .then(data => {
                const fileContent = atob(data.content);
                const fileJson = JSON.parse(fileContent);
                const lastUpdateTime = new Date(fileJson.timestamp);
                const currentTime = new Date();
                const hoursSinceLastUpdate = (currentTime - lastUpdateTime) / (1000 * 60 * 60);

                if (hoursSinceLastUpdate > 20) {
                    window.location.href = 'https://www.9now.com.au/live/channel-9';
                } else {
                    console.log("9Now M3U8 link updates not needed yet.");
                }
            })
            .catch(error => console.error('Error fetching timestamp:', error));
        });
    }

    function getGithubTokenAndUpdateFile(content) {
        chrome.runtime.sendMessage({ action: "getGithubToken" }, function(response) {
            const token = response.token;
            if (!token) {
                console.error("GitHub token not found!");
                return;
            }
            chrome.runtime.sendMessage({ action: "uploadFile", content: content, token: token });
        });
    }

    setInterval(checkIfUpdateNeeded, 30000); // Check every 5 minutes

    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            if (mutation.type === 'childList' || mutation.type === 'attributes') {
                handleStreamUrl();
            }
        }
    });

    if (window.location.href === 'https://www.9now.com.au/live/channel-9') {
        clearClipboard();
        if (!isSniffing) {
            isSniffing = true;
            localStorage.setItem(TOGGLE_KEY, JSON.stringify(isSniffing));
            observer.observe(document.body, {
                childList: true,
                subtree: true,
                attributes: true
            });
            handleStreamUrl();
        }
    }

    if (isSniffing && window.location.href !== 'https://www.9now.com.au/') {
        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true
        });

        handleStreamUrl();
    }

    // Check if the current URL is https://www.9now.com.au/
    if (window.location.href.startsWith('https://www.9now.com.au/')) {
        const toggleDiv = document.createElement('div');
        toggleDiv.style.position = 'fixed';
        toggleDiv.style.bottom = '10px';
        toggleDiv.style.left = '10px';
        toggleDiv.style.zIndex = '9999';
        toggleDiv.style.padding = '10px';
        toggleDiv.style.backgroundColor = '#000';
        toggleDiv.style.border = '1px solid #ccc';
        toggleDiv.style.borderRadius = '4px';
        toggleDiv.style.cursor = 'pointer';
        toggleDiv.style.boxShadow = '0 2px 5px rgba(0,0,0,0.1)';
        toggleDiv.style.display = 'flex';
        toggleDiv.style.alignItems = 'center';

        const toggleLabel = document.createElement('label');
        toggleLabel.style.marginLeft = '8px';
        toggleLabel.textContent = 'Sniff Away';
        toggleLabel.style.background = 'linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet)';
        toggleLabel.style.webkitBackgroundClip = 'text';
        toggleLabel.style.webkitTextFillColor = 'transparent';
        toggleLabel.style.fontSize = '14px';
        toggleDiv.appendChild(toggleLabel);

        const toggleInput = document.createElement('input');
        toggleInput.id = 'sniffAwayToggle';
        toggleInput.type = 'checkbox';
        toggleInput.checked = isSniffing;
        toggleInput.style.display = 'none';
        toggleDiv.appendChild(toggleInput);

        const switchSpan = document.createElement('span');
        switchSpan.style.position = 'relative';
        switchSpan.style.backgroundColor = isSniffing ? '#AD68FF' : '#ccc';
        switchSpan.style.width = '34px';
        switchSpan.style.height = '15px';
        switchSpan.style.transition = '0.4s';
        switchSpan.style.borderRadius = '28px';
        switchSpan.style.display = 'inline-block';
        switchSpan.style.cursor = 'pointer';
        switchSpan.style.marginRight = '5px';
        toggleDiv.appendChild(switchSpan);

        const knobSpan = document.createElement('span');
        knobSpan.style.position = 'absolute';
        knobSpan.style.left = isSniffing ? '3px' : '20px';
        knobSpan.style.bottom = '0.075em';
        knobSpan.style.width = '14px';
        knobSpan.style.height = '13px';
        knobSpan.style.borderRadius = '28px';
        knobSpan.style.backgroundColor = 'white';
        knobSpan.style.transition = '0.4s';
        knobSpan.style.display = 'block';
        knobSpan.style.zIndex = '1';
        switchSpan.appendChild(knobSpan);

        toggleDiv.addEventListener('click', () => {
            isSniffing = !isSniffing;
            localStorage.setItem(TOGGLE_KEY, JSON.stringify(isSniffing));
            updateToggleHTML();

            if (isSniffing) {
                observer.observe(document.body, {
                    childList: true,
                    subtree: true,
                    attributes: true
                });
                handleStreamUrl();
            } else {
                observer.disconnect();
            }
        });

        document.body.appendChild(toggleDiv);

        function updateToggleHTML() {
            toggleInput.checked = isSniffing;
            switchSpan.style.backgroundColor = isSniffing ? '#AD68FF' : '#ccc';
            knobSpan.style.transform = isSniffing ? 'translateX(0)' : 'translateX(15px)';
        }
    }

})();
