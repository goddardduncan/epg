chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ sniffAwayToggle: false });
});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === "getGithubToken") {
        chrome.storage.local.get(['githubToken'], function(result) {
            sendResponse({ token: result.githubToken });
        });
        return true;  // Keeps the message channel open for sendResponse
    } else if (request.action === "uploadFile") {
        chrome.storage.local.get(['githubPath'], function(result) {
            const path = result.githubPath;
            if (!path) {
                console.error("GitHub file path not found!");
                return;
            }
            getFileShaAndUpdate(request.content, request.token, path);
        });
    }
});

function uploadFile(content, sha, token, path) {
    fetch(path, {
        method: "PUT",
        headers: {
            "Authorization": `token ${token}`,
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            message: "Update file via Chrome extension",
            content: btoa(content), // Encode content to base64
            sha: sha
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.commit) {
            console.log("File updated successfully");
            chrome.notifications.create({
                type: "basic",
                iconUrl: "images/icon48.png",
                title: "9Now Sniffer",
                message: "File updated successfully"
            });
        } else {
            console.error("Failed to update file", data);
        }
    })
    .catch(error => console.error("Error uploading file:", error));
}

function getFileShaAndUpdate(content, token, path) {
    fetch(path, {
        method: "GET",
        headers: {
            "Authorization": `token ${token}`,
            "Content-Type": "application/json"
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.sha) {
            uploadFile(content, data.sha, token, path);
        } else {
            console.error("Failed to retrieve file SHA", data);
        }
    })
    .catch(error => console.error("Error getting file SHA:", error));
}
